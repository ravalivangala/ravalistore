<?php
class Cart_model extends CI_Model
{
 function products()
 {
  $query = $this->db->get("product");
  return $query->result();
 }
 function bycategory($Category)
 {
 	$this->db->select('*');
$this->db->where('pcategorie',$Category);
  $query = $this->db->get("product");
  return $query->result();
 }
  function categories()
 {
  $query = $this->db->get("categories");
  return $query->result();
 }
}