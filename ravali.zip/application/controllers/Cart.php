<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {

public function __construct() {
 
parent::__construct();
$this->load->helper('url');
$this->load->library("cart");
$this->load->model("Cart_model");
}

	public function index()

	{

		$this->load->view('tpl/home');
        $data["product"] = $this->Cart_model->products();
        $data["categories"] = $this->Cart_model->categories();
        $this->load->view('products',$data);
		$this->load->view('tpl/footer');

	}
	function byCategory()


	{
$Category = $this->uri->segment(3);

		$this->load->view('tpl/home');
        $data["product"] = $this->Cart_model->byCategory($Category);
        $data["categories"] = $this->Cart_model->categories();
        $this->load->view('products',$data);
		$this->load->view('tpl/footer');
	

	}

	

	function add()
 {
 	
if (isset($_POST["quantity"])) {
 

        $id1    = $_POST["product_id"];
        $qty1     = $_POST["quantity"];
        $price1   = $_POST["product_price"];
        $name1    = $_POST["product_name"];
  
  //$this->cart->insert($data); 
  //echo $this->view();

         $data = array(
   "id"  => $id1,
   "name"  => $name1,
   "qty"  => $qty1,
   "price"  => $price1
  );
  //print_r($data);
  $this->cart->insert($data); 
  echo $this->view();
         
}



 }


 function load()
 {
  echo $this->view();
 }


 function view()
 {
  
  $output = '';
  $output .= '

<img align="center" src="'.base_url().'assets/img/fullcart.jpg" alt="" style="height:50px;width:50px;">
  <div class="table-responsive">
   <div align="right">
    
   </div>
   <br />
   <table class="table table-bordered">
    <tr>
     <th width="60%">Name</th>
     <th width="10%">Quantity</th>
     <th width="10%">Price</th>
     <th width="10%">Total</th>
     <th width="10%">Action</th>
    </tr>

  ';
  $count = 0;
  foreach($this->cart->contents() as $items)
  {
   $count++;
   $output .= '
   <tr> 
    <td>'.$items["name"].'</td>
    <td>'.$items["qty"].'</td>
    <td>'.$items["price"].'</td>
    <td>'.$items["subtotal"].'</td>
    <td><button type="button" name="remove" class="btn btn-danger btn-xs remove_inventory" id="'.$items["rowid"].'">Remove</button></td>
   </tr>
   ';
  }
  $output .= '
   <tr>
    <td colspan="4" align="right">Total</td>
    <td><b>'.$this->cart->total().'</b></td>
   </tr>
  </table>

  </div>
  ';

  if($count == 0)
  {
   $output = '<img align="center" src="'.base_url().'assets/img/emptycart.jpg" alt="" style="height:50px;width:50px;">
   <h4 align="center">Cart is Empty</h4>';
  }
  return $output;
 

}


function remove()
 {

  $row_id = $_POST["row_id"];
  $data = array(
   'rowid'  => $row_id,
   'qty'  => 0
  );
  $this->cart->update($data);
  echo $this->view();
 }

 function clear()
 {

  $this->cart->destroy();
  echo $this->view();
 }

}
