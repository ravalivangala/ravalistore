  <!-- Page Content -->
  <div class="container">

 <div class="row align-items-center my-5">
      <div class="col-lg-7">
        <img class="img-fluid rounded mb-4 mb-lg-0" src="<?php echo base_url(); ?>assets/img/banner.png" alt="">
      </div>
      <!-- /.col-lg-8 -->
      <div class="col-lg-5">
        
      

        <button type="button" style="height:70px;width:250px;" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
<img src="<?php echo base_url(); ?>assets/img/cart.png" style="height:50px;width:50px;"> CART
</button>
      </div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">CART</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div id="cart_details">
      
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" id="clear_cart" class="btn btn-warning">Clear Cart</button>
        <button type="button" class="btn btn-primary">Checkout</button>
      </div>
    </div>
  </div>
</div>
      <!-- /.col-md-4 -->
    </div>
    <!-- /.row -->

  

    <div class="row">

      <div class="col-lg-3">


        <h1 class="my-4">Categories</h1>
        <div class="list-group">
        <?php
   foreach($categories as $row)
   {
    echo
          '<a href="'.base_url().'cart/byCategory/'.$row->cname.'" class="list-group-item">'.$row->cname.'</a>
        ';
          }
   ?>
        </div>

      </div>
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">

       

        <div class="row">





 <?php
   foreach($product as $row)
   {
    echo
          '<div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
              <a href="#"><img class="card-img-top" src="'.base_url().'assets/img/'.$row->pimg.'" alt="" style="height:150px;width:150px;"></a>
              <div class="card-body">
                <h4 class="card-title">
                  <a href="#">'.$row->pname.'</a>
                </h4>
                <h5>Price: Rs'.$row->pprice.'/-</h5>
                <p class="card-text">'.$row->pdis.'</p>
              </div>
              <div class="card-footer">
                <input type="text" size="2" value="1" style="width:50px;"name="quantity" class="form-control quantity" id="'.$row->pid.'" />
                <button type="button" name="add_cart" class="btn btn-success add_cart" data-product_name="'.$row->pname.'" data-product_price="'.$row->pprice.'" data-product_id="'.$row->pid.'" />Add to Cart</button>
              </div>
            </div>
          </div>';
   }
   ?>

         
      </div>
      <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

  </div>

